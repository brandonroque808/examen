import './Footer.css';

export default function Footer() {
  return (
    <footer className="footer">
      © 2025 Sergio el Bailador
    </footer>
  );
}
